// Color.kt - empty placeholder
