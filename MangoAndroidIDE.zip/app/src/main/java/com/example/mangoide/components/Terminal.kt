// Terminal.kt - empty placeholder
