// Type.kt - empty placeholder
