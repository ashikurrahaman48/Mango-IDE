// EditorViewModel.kt - empty placeholder
