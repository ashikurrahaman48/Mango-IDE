// Editor.kt - empty placeholder
