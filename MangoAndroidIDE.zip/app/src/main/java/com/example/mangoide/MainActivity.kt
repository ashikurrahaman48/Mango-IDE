// MainActivity.kt - empty placeholder
