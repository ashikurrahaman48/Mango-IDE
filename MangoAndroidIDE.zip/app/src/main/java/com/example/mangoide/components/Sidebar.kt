// Sidebar.kt - empty placeholder
